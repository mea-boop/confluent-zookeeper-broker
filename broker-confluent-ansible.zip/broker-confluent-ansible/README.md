# Confluent Kafka Broker Ansible Deployment

## Overview

Ansible automation for deploying Confluent Kafka Broker cluster on prd-eastus2-az3 environment using Ansible Automation Platform.

## Target Environment

**Hosts:**
- broker1-east-az3.prd.eeh.humana.com  (Broker ID: 35)
- broker2-east-az3.prd.eeh.humana.com  (Broker ID: 37)
- broker3-east-az3.prd.eeh.humana.com  (Broker ID: 39)

**Configuration:**
- Confluent Version: 7.5.0
- Source: /tmp/confluent-7.5.0.tar (local package on each host)
- User/Group: kafka/kafka
- Install Dir: /opt/confluent
- Data Dir: /app/kafka1/data
- Log Dir: /var/log/kafka
- Secrets Dir: /opt/secrets (mode 0700)

## Project Structure

```
broker-confluent-ansible/
├── playbooks/
│   ├── deploy_broker.yml              # Main deployment (rolling, serial: 1)
│   └── restart_broker.yml             # Intelligent restart (leader last)
├── roles/
│   └── broker/
│       ├── tasks/
│       │   ├── main.yml               # Orchestrates all task includes
│       │   ├── create_user.yml        # Create kafka user/group
│       │   ├── create_directories.yml # Create all required directories
│       │   ├── install_confluent.yml  # Extract tar, install binaries
│       │   ├── setup_prometheus.yml   # Deploy JMX exporter JAR + config
│       │   ├── deploy_secrets.yml     # Deploy local-secrets.properties from AAP creds
│       │   ├── configure.yml          # Deploy server.properties, log4j, broker-env.sh
│       │   ├── configure_service.yml  # Deploy systemd unit file
│       │   ├── start_service.yml      # Enable, start, wait for ports
│       │   └── validate.yml           # Health checks and port validation
│       ├── templates/
│       │   ├── server.properties.j2             # Full broker config (all properties)
│       │   ├── local-secrets.properties.j2      # SecurePass secrets file (from AAP creds)
│       │   ├── broker-env.sh.j2                 # JVM, JMX, Prometheus environment
│       │   ├── confluent-kafka.service.j2        # Systemd service unit
│       │   ├── log4j.properties.j2              # Broker logging config
│       │   └── jmx-kafka-broker-prometheus.yml.j2  # Prometheus JMX metrics config
│       ├── handlers/main.yml          # reload systemd, restart confluent-kafka
│       └── defaults/main.yml          # Overridable feature flags
├── group_vars/
│   └── broker_nodes.yml               # All non-sensitive variables
├── docs/
│   └── AAP_SETUP.md                   # AAP setup guide
├── .gitignore                          # Excludes secrets, keys, logs
└── README.md                           # This file
```

## Features

✅ **FQDN-based Configuration** - Uses `ansible_fqdn` throughout all templates  
✅ **Broker ID from AAP** - `broker_id_map` keyed by FQDN, resolved per host  
✅ **No Secrets in Git** - All passwords/license from AAP Custom Credentials only  
✅ **SecurePass Integration** - `server.properties` contains only `${securepass:...}` placeholders  
✅ **local-secrets.properties** - Deployed by Ansible, mode 0600, never committed  
✅ **Prometheus JMX Exporter** - Port 7071, auto-configured and starts with broker  
✅ **JMX Monitoring** - Port 9999 enabled  
✅ **Leader-Last Restart** - Non-leader brokers restart first, leader broker restarts last  
✅ **No Shell Scripts** - 100% native Ansible built-in modules  
✅ **Mirrors Zookeeper Structure** - Same folder layout and task file pattern  

## Prerequisites

### On Target Hosts

1. **Java installed** (version 11 or later)
2. **Confluent package** at `/tmp/confluent-7.5.0.tar`
3. **SSL material** in `/opt/ssl/` (truststore.jks, keystore.pfx, mdskeypair.pem, mdspublic.pem)
4. **Firewall disabled** (or ports manually opened)
5. **SSH access** configured for AAP automation user
6. **Sudo permissions** for deployment user
7. **FQDNs configured** (`hostname -f` returns FQDN)

### Required Ports

| Port | Purpose                   |
|------|---------------------------|
| 9093 | SASL_SSL (inter-broker, clients, leader election) |
| 9092 | TOKEN (OAuth Bearer / MDS tokens) |
| 9094 | AD (LDAP / Active Directory Plain) |
| 8090 | MDS REST API              |
| 9999 | JMX (internal)            |
| 7071 | Prometheus metrics scrape |

## Quick Start

### 1. Place JMX Prometheus JAR

Copy `jmx_prometheus_javaagent-0.20.0.jar` into:
```
roles/broker/files/jmx_prometheus_javaagent-0.20.0.jar
```

### 2. Upload to Azure DevOps

```bash
git init
git add .
git commit -m "Initial commit: Confluent Kafka Broker Ansible"
git remote add origin https://dev.azure.com/<org>/<project>/_git/broker-ansible
git push -u origin main
```

### 3. Configure AAP

See `docs/AAP_SETUP.md` for full steps:
1. Create inventory: `Kafka_Broker_prd_eastus2_az3`
2. Create group: `broker_nodes`
3. Add 3 broker hosts with FQDNs
4. Create AAP Custom Credential with all secrets
5. Create project from Azure DevOps
6. Create job templates

### 4. Deploy

Run job template: `Deploy_Kafka_Broker_prd`

## Secret Flow

```
AAP Custom Credential (encrypted)
    ↓ injected as extra_vars at runtime
Ansible template module
    ↓ renders local-secrets.properties.j2
/opt/secrets/local-secrets.properties  (mode 0600, kafka:kafka)
    ↓ read by Confluent SecurePass at JVM startup
server.properties ${securepass:...} placeholders resolved in JVM memory only
```

**server.properties on disk contains ZERO plaintext secrets.**

## AAP Custom Credential Variables Required

| Variable               | Description                     |
|------------------------|---------------------------------|
| `confluent_license`    | Confluent Platform license JWT  |
| `kafka_admin_password` | SCRAM-SHA-256 admin password    |
| `ldap_bind_password`   | LDAP service account password   |
| `ssl_truststore_password` | JKS truststore password      |
| `ssl_keystore_password`   | PFX keystore password        |
| `ssl_key_password`        | PFX private key password     |

## Monitoring

### Prometheus Integration

Add to `prometheus.yml`:

```yaml
scrape_configs:
  - job_name: 'confluent-kafka-brokers-prd'
    scrape_interval: 30s
    static_configs:
      - targets:
          - 'broker1-east-az3.prd.eeh.humana.com:7071'
          - 'broker2-east-az3.prd.eeh.humana.com:7071'
          - 'broker3-east-az3.prd.eeh.humana.com:7071'
        labels:
          env: 'production'
          cluster: 'east-az3'
```

## Restart Procedure

Use the intelligent restart playbook (Job Template: `Restart_Kafka_Broker_prd`):

**What happens:**
1. Queries MDS REST API to count leader partitions per broker
2. Identifies the broker holding the most leader partitions
3. Restarts non-leader brokers first (one at a time, health-checked)
4. Restarts the leader broker last
5. Kafka `controlled.shutdown` handles leader re-election automatically before each stop

**Result:** Only ONE leader election per partition set during the entire rolling restart.

---

**Version:** 1.0  
**Environment:** prd-eastus2-az3  
**Last Updated:** {{ lookup('pipe', 'date +%Y-%m-%d') }}
